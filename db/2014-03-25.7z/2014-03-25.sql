/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.35-0ubuntu0.12.04.2 : Database - nailsalon
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`nailsalon` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `nailsalon`;

/*Table structure for table `Payment` */

CREATE TABLE `Payment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticketId` int(10) unsigned NOT NULL,
  `paymentMethodId` int(10) unsigned NOT NULL,
  `amount` double unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ticketId` (`ticketId`),
  KEY `idx_paymentMethodId` (`paymentMethodId`),
  CONSTRAINT `fk_Payment_paymentMethodId` FOREIGN KEY (`paymentMethodId`) REFERENCES `PaymentMethod` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Payment_ticketId` FOREIGN KEY (`ticketId`) REFERENCES `Ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `Payment` */

/*Table structure for table `PaymentMethod` */

CREATE TABLE `PaymentMethod` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `PaymentMethod` */

/*Table structure for table `Product` */

CREATE TABLE `Product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(10) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` double unsigned DEFAULT NULL,
  `isActive` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_storeId` (`storeId`),
  CONSTRAINT `fk_Product_Store` FOREIGN KEY (`storeId`) REFERENCES `Store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

/*Data for the table `Product` */

insert  into `Product`(`id`,`storeId`,`name`,`price`,`isActive`) values (2,1,'Acrylics Fullset',20,1),(3,1,'Acrylics Fill',25,1),(4,1,'Solar Pink / White Fullset',35,1),(5,1,'Solar Pink / White Fill',20,1),(6,1,'White tip Fullset',25,1),(7,1,'White tip Fill',13,1),(8,1,'Pearl Nails (glitter) Fullset',30,1),(9,1,'Pearl Nails (glitter) Fill',30,1),(10,1,'Powder gel Fullset',35,1),(11,1,'Powder gel Fill',20,1),(12,1,'Tip removal (take-off)',10,1),(13,1,'Nail repair',3,1),(14,1,'Sculpture Fullset',30,1),(15,1,'Sculpture FIll',18,1),(16,1,'French',5,1),(17,1,'Gel Coating',5,1),(18,1,'Nail Art',5,1),(19,1,'Gel nails',25,1),(20,1,'Cut down',2,1),(21,1,'Polish Change',8,1),(22,1,'Regular manicure',12,1),(23,1,'Special manicure',20,1),(24,1,'Regular pedicure',20,1),(25,1,'Deluxe pedicure',30,1),(26,1,'Fancy Signature pedicure',35,1);

/*Table structure for table `Queue` */

CREATE TABLE `Queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `storeId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL,
  `position` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_Queue_Store1_idx` (`storeId`),
  KEY `fk_Queue_User1_idx` (`userId`),
  CONSTRAINT `fk_Queue_Store1` FOREIGN KEY (`storeId`) REFERENCES `Store` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Queue_User1` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `Queue` */

insert  into `Queue`(`id`,`dateCreated`,`storeId`,`userId`,`position`) values (1,'2013-10-02 00:00:00',1,1,1),(2,'2013-10-02 00:00:00',1,1,2),(13,'2013-10-12 17:00:04',1,2,6),(14,'2013-10-12 17:00:15',1,1,7),(15,'2013-10-12 17:02:46',1,13,8),(16,'2013-10-12 17:44:12',1,3,9);

/*Table structure for table `Role` */

CREATE TABLE `Role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `Role` */

insert  into `Role`(`id`,`name`) values (1,'Owner'),(2,'Technician');

/*Table structure for table `Store` */

CREATE TABLE `Store` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alias` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `isActive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `defaultCommissionRatio` int(10) unsigned NOT NULL DEFAULT '60',
  `turnThresholdAmount` int(10) unsigned NOT NULL DEFAULT '20',
  `isAutoTipDivision` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `isAutoTaskAssignment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `taskAssignmentMethod` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_Store_taskAssignmentMethod` (`taskAssignmentMethod`),
  CONSTRAINT `FK_Store_taskAssignmentMethod` FOREIGN KEY (`taskAssignmentMethod`) REFERENCES `TaskAssignmentMethod` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `Store` */

insert  into `Store`(`id`,`alias`,`name`,`address`,`phone`,`isActive`,`defaultCommissionRatio`,`turnThresholdAmount`,`isAutoTipDivision`,`isAutoTaskAssignment`,`taskAssignmentMethod`) values (1,'nail-center','Nail Center','3810 South Cooper Street, Suite #146, Arlington, Texas 76015',8175574488,1,60,20,1,1,1);

/*Table structure for table `StoreCustomer` */

CREATE TABLE `StoreCustomer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_StoreCustomer_Store1_idx` (`storeId`),
  KEY `fk_StoreCustomer_User1_idx` (`userId`),
  CONSTRAINT `fk_StoreCustomer_Store1` FOREIGN KEY (`storeId`) REFERENCES `Store` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_StoreCustomer_User1` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `StoreCustomer` */

/*Table structure for table `StoreUserRole` */

CREATE TABLE `StoreUserRole` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `roleId` int(10) unsigned NOT NULL,
  `storeId` int(10) unsigned NOT NULL,
  `userId` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Idx_roleId` (`roleId`),
  KEY `idx_storeId` (`storeId`),
  KEY `idx_userId` (`userId`),
  KEY `uq_StoreUserRole` (`roleId`,`storeId`,`userId`),
  CONSTRAINT `fk_StoreUserRole_roleId` FOREIGN KEY (`roleId`) REFERENCES `Role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_StoreUserRole_storeId` FOREIGN KEY (`storeId`) REFERENCES `Store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_StoreUserRole_userId` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `StoreUserRole` */

insert  into `StoreUserRole`(`id`,`roleId`,`storeId`,`userId`) values (1,1,1,1),(6,1,1,13),(2,2,1,2),(3,2,1,3);

/*Table structure for table `Task` */

CREATE TABLE `Task` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ticketId` int(10) unsigned NOT NULL,
  `productId` int(10) unsigned NOT NULL,
  `assigneeId` int(10) unsigned NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `tip` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ticketId` (`ticketId`),
  KEY `idx_productId` (`productId`),
  KEY `idx_assigneeId` (`assigneeId`),
  KEY `uq_Task` (`ticketId`,`productId`,`assigneeId`),
  CONSTRAINT `fk_Task_assigneeId` FOREIGN KEY (`assigneeId`) REFERENCES `User` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Task_productId` FOREIGN KEY (`productId`) REFERENCES `Product` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Task_ticketId` FOREIGN KEY (`ticketId`) REFERENCES `Ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

/*Data for the table `Task` */

insert  into `Task`(`id`,`ticketId`,`productId`,`assigneeId`,`price`,`tip`) values (2,2,26,1,35,0),(19,1,2,13,20,0),(21,1,9,13,30,0),(25,1,24,3,20,0),(28,1,14,2,30,0),(29,2,18,3,5,0),(32,2,21,1,8,0),(33,2,12,3,10,0),(38,8,18,3,5,0),(39,8,14,2,30,0),(40,8,26,3,35,0),(41,8,4,1,35,0),(42,8,25,13,30,0);

/*Table structure for table `TaskAssignmentMethod` */

CREATE TABLE `TaskAssignmentMethod` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `TaskAssignmentMethod` */

insert  into `TaskAssignmentMethod`(`id`,`name`) values (1,'Lowest Income First'),(2,'Lowest Turn First');

/*Table structure for table `Ticket` */

CREATE TABLE `Ticket` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `storeId` int(10) unsigned NOT NULL,
  `cutomerId` int(10) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_storeId` (`storeId`),
  KEY `idx_customerId` (`cutomerId`),
  CONSTRAINT `fk_Ticket_customerId` FOREIGN KEY (`cutomerId`) REFERENCES `StoreCustomer` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Ticket_storeId` FOREIGN KEY (`storeId`) REFERENCES `Store` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

/*Data for the table `Ticket` */

insert  into `Ticket`(`id`,`storeId`,`cutomerId`,`dateCreated`) values (1,1,NULL,'2013-10-12 19:04:27'),(2,1,NULL,'2013-10-12 20:40:31'),(3,1,NULL,'2013-10-12 22:54:35'),(4,1,NULL,'2013-10-12 22:55:07'),(5,1,NULL,'2013-10-12 22:59:40'),(6,1,NULL,'2013-10-12 23:00:12'),(7,1,NULL,'2013-10-12 23:13:09'),(8,1,NULL,'2013-10-12 23:14:40');

/*Table structure for table `User` */

CREATE TABLE `User` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` bigint(10) NOT NULL,
  `pin` int(11) NOT NULL,
  `isActive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `User` */

insert  into `User`(`id`,`name`,`email`,`phone`,`pin`,`isActive`) values (1,'Hang Nguyen','hangnguyen@gmail.com',8177606689,1234,1),(2,'Tran Nguyen','trannguyen@gmail.com',8172458795,1234,1),(3,'Thuy Phan','thuyphan@gmail.com',8172547512,1234,1),(13,'Duy Nguyen','aduyng@gmail.com',8172721061,1234,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
